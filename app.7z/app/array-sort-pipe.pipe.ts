import { Pipe, PipeTransform } from '@angular/core';


@Pipe({
  name: 'arraySortPipe'
})
export class ArraySortPipePipe implements PipeTransform {

  transform()  {
    

}
}