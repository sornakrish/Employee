import { Component, OnInit, Input } from '@angular/core';
import { MyserviceService, Employee } from '../myservice.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
  
  
  service:MyserviceService;
  constructor(service:MyserviceService) {
    this.service=service; 
  }

  employees:Employee[]=[];
  delete(eid:number)
  {
    this.service.delete(eid);
    this.employees=this.service.getEmployees();
  }
  
  ngOnInit() {
    this.service.fetchEmployees();
    this.employees=this.service.getEmployees();
  }
 
}
