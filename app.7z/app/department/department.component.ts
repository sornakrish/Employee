import { Component, OnInit } from '@angular/core';
import { MyserviceService, Department } from 'src/myservice.service';

@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.css']
})
export class DepartmentComponent implements OnInit {

  
  service:MyserviceService;
  constructor(service:MyserviceService) {
    this.service=service; 
  }

  department:Department[]=[];

  delete(id:number){
    this.service.delete(id);
    this.department=this.service.getDepartment();
  }
  column:string="id"; 
  order:boolean=true;
  sort(column:string){
    
    if(this.column==column )
    {
      this.order=!this.order;
    }else{
      this.order=true;
      this.column=column;
    }
  }

  ngOnInit() {
    this.service.fetchDepartment();
    this.department=this.service.getDepartment();
  }

  
}

