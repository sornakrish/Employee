import * as platformBrowser from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {HttpClient , HttpClientModule} from '@angular/common/http'
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { MyserviceService } from './myservice.service';
import { ArraySortPipePipe } from './array-sort-pipe.pipe'



@NgModule({
  declarations: [
    AppComponent,
    EmployeeListComponent,
    AddEmployeeComponent,
    ArraySortPipePipe
  ],
  imports: [
    platformBrowser.BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [HttpClient, MyserviceService],
  
  bootstrap: [AppComponent]
})
export class AppModule { }
